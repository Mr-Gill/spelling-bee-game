export const avatars = {
  bee: { name: 'Bee', icon: '/img/avatars/bee.svg' },
  book: { name: 'Book', icon: '/img/avatars/book.svg' },
  trophy: { name: 'Trophy', icon: '/img/avatars/trophy.svg' },
  wizard: { name: 'Wizard', icon: '/img/avatars/bee.svg' },
  ninja: { name: 'Ninja', icon: '/img/avatars/book.svg' },
};
