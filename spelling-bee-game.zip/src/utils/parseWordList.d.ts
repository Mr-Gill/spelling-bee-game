import { Word } from '../types';
export function parseWordList(content: string): Word[];
