declare module './components/AudioSettings' {
  declare const AudioSettings: React.ComponentType;
  export default AudioSettings;
}
